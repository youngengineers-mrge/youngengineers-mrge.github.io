from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from html import escape
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse
from datetime import datetime
from zoneinfo import ZoneInfo
from logging.handlers import RotatingFileHandler
import logging
import os
import re
import socket
import subprocess
import webbrowser

PORT = 8000
BASIS_ORDNER = Path(__file__).resolve().parent
UPLOAD_ORDNER = BASIS_ORDNER / "upload"
DOWNLOAD_ORDNER = BASIS_ORDNER / "download"
ALTE_UPLOAD_ORDNER = BASIS_ORDNER / "uploads"
ALTE_DOWNLOAD_ORDNER = BASIS_ORDNER / "downloads"
MINECRAFT_ORDNER = BASIS_ORDNER / "minecraft"
MINECRAFT_INSTANZEN_ORDNER = BASIS_ORDNER / "minecraft" / "instanzen"
MINECRAFT_26_2_ORDNER = MINECRAFT_INSTANZEN_ORDNER / "26.2"
MINECRAFT_26_2_SAVES_ORDNER = MINECRAFT_26_2_ORDNER / "saves"
MAX_GROESSE = 200 * 1024 * 1024   # 200 MB
LOG_ORDNER = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "YoungEngineers" / "AG-Server"
LOG_DATEI = LOG_ORDNER / "ag-server.log"

for alte_ablage, neue_ablage in (
    (ALTE_UPLOAD_ORDNER, UPLOAD_ORDNER),
    (ALTE_DOWNLOAD_ORDNER, DOWNLOAD_ORDNER),
):
    if alte_ablage.is_dir() and not neue_ablage.exists():
        alte_ablage.rename(neue_ablage)

UPLOAD_ORDNER.mkdir(parents=True, exist_ok=True)
DOWNLOAD_ORDNER.mkdir(parents=True, exist_ok=True)
MINECRAFT_ORDNER.mkdir(parents=True, exist_ok=True)
for minecraft_ordner in (
    MINECRAFT_26_2_ORDNER / "mods",
    MINECRAFT_26_2_ORDNER / "resourcepacks",
    MINECRAFT_26_2_SAVES_ORDNER,
    MINECRAFT_26_2_ORDNER / "schematics",
):
    minecraft_ordner.mkdir(parents=True, exist_ok=True)

LOG_ORDNER.mkdir(parents=True, exist_ok=True)
TRANSFER_LOG = logging.getLogger("AG-Server-Transfers")
TRANSFER_LOG.setLevel(logging.INFO)
if not TRANSFER_LOG.handlers:
    log_handler = RotatingFileHandler(
        LOG_DATEI,
        maxBytes=2 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    log_handler.setFormatter(logging.Formatter("%(asctime)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    TRANSFER_LOG.addHandler(log_handler)

TRANSFER_LOG_MUSTER = re.compile(
        r"^(?P<zeit>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) "
        r"(?P<aktion>UPLOAD|DOWNLOAD|DELETE) Serverrechner=(?P<rechner>\S+) "
        r"ClientIP=(?P<client>\S+) Datei=(?P<datei>.*?) "
        r"Bytes=(?P<bytes>\d+) HTTP=(?P<status>\d+)$"
)


def transferprotokoll_html() -> str:
        eintraege = []
        for log_datei in LOG_ORDNER.glob("ag-server.log*"):
                try:
                        zeilen = log_datei.read_text(encoding="utf-8", errors="replace").splitlines()
                except OSError:
                        continue
                for zeile in zeilen:
                        treffer = TRANSFER_LOG_MUSTER.match(zeile)
                        if treffer:
                                eintraege.append(treffer.groupdict())

        eintraege.sort(key=lambda eintrag: eintrag["zeit"], reverse=True)
        zeilen_html = []
        for eintrag in eintraege:
                attrs = " ".join(
                        f'data-{attribut}="{escape(wert, quote=True)}"'
                        for attribut, wert in eintrag.items()
                )
                zeilen_html.append(
                        f"<tr {attrs}>"
                        f"<td>{escape(eintrag['zeit'])}</td>"
                        f"<td>{escape(eintrag['aktion'])}</td>"
                        f"<td>{escape(eintrag['rechner'])}</td>"
                        f"<td>{escape(eintrag['client'])}</td>"
                        f"<td>{escape(eintrag['datei'])}</td>"
                        f"<td data-wert=\"{eintrag['bytes']}\">{int(eintrag['bytes']):,}</td>"
                        f"<td>{escape(eintrag['status'])}</td>"
                        "</tr>"
                )

        if not zeilen_html:
                zeilen_html.append('<tr><td colspan="7">Noch keine Transferereignisse protokolliert.</td></tr>')

        return f'''<!doctype html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AG-Server | Transferprotokoll</title>
    <style>
        :root {{ color-scheme: light; --ink: #1d2a35; --muted: #66737d; --paper: #f6f3ed; --panel: #fffdf9; --line: #d9d5cc; --teal: #236f70; --accent: #d45b36; }}
        * {{ box-sizing: border-box; }}
        body {{ margin: 0; color: var(--ink); background: var(--paper); font-family: Georgia, "Times New Roman", serif; }}
        main {{ width: min(1280px, calc(100% - 32px)); margin: 0 auto; padding: 36px 0 48px; }}
        h1 {{ margin: 0 0 12px; font-size: 2.2rem; font-weight: 400; }}
        .topline {{ display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 24px; }}
        a {{ color: var(--teal); font: 700 .9rem Arial, sans-serif; }}
        .controls {{ display: flex; flex-wrap: wrap; align-items: end; gap: 12px; margin-bottom: 12px; }}
        label {{ display: grid; gap: 6px; color: var(--muted); font: 700 .82rem Arial, sans-serif; }}
        input, select {{ min-height: 40px; max-width: 100%; padding: 8px 10px; border: 1px solid var(--line); border-radius: 4px; color: var(--ink); background: var(--panel); font: .92rem Arial, sans-serif; }}
        #filter {{ width: min(420px, 100%); }}
        #treffer {{ min-height: 1.4em; color: var(--muted); font: .85rem Arial, sans-serif; }}
        .table-wrap {{ overflow: auto; max-height: calc(100vh - 190px); border: 1px solid var(--line); background: var(--panel); }}
        table {{ width: 100%; border-collapse: collapse; font: .84rem/1.4 Arial, sans-serif; }}
        th, td {{ padding: 9px 10px; border-bottom: 1px solid var(--line); text-align: left; vertical-align: top; }}
        th {{ position: sticky; top: 0; color: var(--ink); background: #ece9e1; white-space: nowrap; }}
        td {{ overflow-wrap: anywhere; }}
        td:nth-child(1), td:nth-child(3), td:nth-child(4), td:nth-child(6), td:nth-child(7) {{ white-space: nowrap; }}
        tr[hidden] {{ display: none; }}
        @media (max-width: 700px) {{ main {{ padding-top: 24px; }} .table-wrap {{ max-height: none; }} }}
    </style>
</head>
<body>
    <main>
        <div class="topline">
            <h1>Transferprotokoll</h1>
            <a href="/">Zur Startseite</a>
        </div>
        <div class="controls">
            <label for="filter">Einträge filtern
                <input id="filter" type="search" placeholder="Rechner, Datei, Client-IP …">
            </label>
            <label for="sortierung">Sortieren
                <select id="sortierung">
                    <option value="zeit:desc">Neueste zuerst</option>
                    <option value="zeit:asc">Älteste zuerst</option>
                    <option value="aktion:asc">Aktion</option>
                    <option value="rechner:asc">Rechnername</option>
                    <option value="client:asc">Client-IP</option>
                    <option value="datei:asc">Dateiname</option>
                    <option value="bytes:desc">Größe: größte zuerst</option>
                    <option value="status:asc">HTTP-Status</option>
                </select>
            </label>
        </div>
        <p id="treffer" role="status" aria-live="polite"></p>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Datum und Uhrzeit</th><th>Aktion</th><th>Serverrechner</th><th>Client-IP</th><th>Datei</th><th>Bytes</th><th>HTTP</th></tr></thead>
                <tbody id="eintraege">
{chr(10).join(zeilen_html)}
                </tbody>
            </table>
        </div>
    </main>
    <script>
        const filter = document.querySelector("#filter");
        const sortierung = document.querySelector("#sortierung");
        const treffer = document.querySelector("#treffer");
        const tabelle = document.querySelector("#eintraege");
        const zeilen = [...tabelle.querySelectorAll("tr[data-zeit]")];

        function aktualisieren() {{
            const suchtext = filter.value.trim().toLocaleLowerCase("de");
            const [schluessel, richtung] = sortierung.value.split(":");
            const passend = zeilen.filter((zeile) => zeile.textContent.toLocaleLowerCase("de").includes(suchtext));
            passend.sort((a, b) => {{
                const links = schluessel === "bytes" ? Number(a.dataset.bytes) : a.dataset[schluessel].toLocaleLowerCase("de");
                const rechts = schluessel === "bytes" ? Number(b.dataset.bytes) : b.dataset[schluessel].toLocaleLowerCase("de");
                const vergleich = typeof links === "number" ? links - rechts : links.localeCompare(rechts, "de");
                return richtung === "desc" ? -vergleich : vergleich;
            }});
            for (const zeile of zeilen) zeile.hidden = !passend.includes(zeile);
            for (const zeile of passend) tabelle.append(zeile);
            treffer.textContent = `${{passend.length}} von ${{zeilen.length}} Transferereignissen`;
        }}

        filter.addEventListener("input", aktualisieren);
        sortierung.addEventListener("change", aktualisieren);
        aktualisieren();
    </script>
</body>
</html>'''


def verzeichnis_html(ordner: Path, titel: str, upload_erlaubt: bool = False) -> str:
    verwaltbare_bereiche = {
        BASIS_ORDNER / "wartung": "wartung",
        UPLOAD_ORDNER: "upload",
        DOWNLOAD_ORDNER: "download",
    }
    bereich = verwaltbare_bereiche.get(ordner, "") if upload_erlaubt else ""
    dateien = sorted(
        datei for datei in ordner.rglob("*") if datei.is_file()
    )
    eintraege = []

    for datei in dateien:
        relativer_pfad = datei.relative_to(BASIS_ORDNER).as_posix()
        anzeige = datei.relative_to(ordner).as_posix()
        link = quote(relativer_pfad, safe="/._-")
        markierung = ""
        if bereich:
            markierung = (
                f'<input class="datei-markierung" type="checkbox" '
                f'value="{escape(anzeige, quote=True)}" '
                f'aria-label="{escape(anzeige, quote=True)} zum Löschen markieren"> '
            )
        eintraege.append(
            f'      <li>{markierung}<a href="/{escape(link, quote=True)}">'
            f"{escape(anzeige)}</a></li>"
        )

    inhalt = "\n".join(eintraege)
    upload_bereich = ""
    upload_script = ""
    loesch_bereich = ""
    loesch_script = ""
    if bereich in {"wartung", "download"}:
        upload_titel = "Dateien hinzufügen" if bereich == "wartung" else "Dateien ins Downloadverzeichnis laden"
        upload_bereich = f'''
        <section class="upload-panel wartung-upload" aria-label="Dateien hochladen">
            <h2>{escape(upload_titel)}</h2>
            <label class="filter-label" for="verzeichnis-dateien">Dateien auswählen</label>
            <input id="verzeichnis-dateien" type="file" data-bereich="{bereich}" multiple>
            <button id="verzeichnis-hochladen" type="button" disabled>Hochladen</button>
            <p id="verzeichnis-upload-status" role="status" aria-live="polite"></p>
        </section>'''
        upload_script = '''
        const dateiAuswahl = document.querySelector("#verzeichnis-dateien");
        const uploadKnopf = document.querySelector("#verzeichnis-hochladen");
        const uploadStatus = document.querySelector("#verzeichnis-upload-status");
        const uploadBereich = dateiAuswahl.dataset.bereich;
        const uploadAdresse = uploadBereich === "wartung" ? "/wartung-upload" : "/download-upload";

        dateiAuswahl.addEventListener("change", () => {
            uploadKnopf.disabled = dateiAuswahl.files.length === 0;
            uploadStatus.textContent = dateiAuswahl.files.length
                ? `${dateiAuswahl.files.length} Datei(en) ausgewählt`
                : "";
        });

        uploadKnopf.addEventListener("click", async () => {
            const dateien = [...dateiAuswahl.files];
            uploadKnopf.disabled = true;

            for (const [index, datei] of dateien.entries()) {
                uploadStatus.textContent = `Lade ${index + 1} von ${dateien.length}: ${datei.name}`;
                try {
                    const antwort = await fetch(
                        uploadAdresse + "?name=" + encodeURIComponent(datei.name),
                        { method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: datei }
                    );
                    const text = await antwort.text();
                    if (!antwort.ok) throw new Error(text || "Upload fehlgeschlagen");
                } catch (fehler) {
                    uploadStatus.textContent = `Upload von ${datei.name} fehlgeschlagen: ${fehler.message}`;
                    uploadStatus.classList.add("error");
                    uploadKnopf.disabled = false;
                    return;
                }
            }

            uploadStatus.classList.remove("error");
            uploadStatus.textContent = `${dateien.length} Datei(en) hochgeladen`;
            window.location.reload();
        });
        '''
    if bereich:
        loesch_bereich = '''
            <div class="loesch-aktion">
                <button id="dateien-loeschen" type="button" disabled>Markierte Dateien löschen</button>
                <p id="loesch-status" role="status" aria-live="polite"></p>
            </div>'''
        loesch_script = '''
        const markierungen = [...document.querySelectorAll(".datei-markierung")];
        const loeschKnopf = document.querySelector("#dateien-loeschen");
        const loeschStatus = document.querySelector("#loesch-status");
        const dateilisteBereich = document.querySelector("#dateiliste").dataset.bereich;

        function loeschAuswahlAktualisieren() {
            const anzahl = markierungen.filter((markierung) => markierung.checked).length;
            loeschKnopf.disabled = anzahl === 0;
            loeschKnopf.textContent = anzahl
                ? `${anzahl} markierte Datei(en) löschen`
                : "Markierte Dateien löschen";
        }

        markierungen.forEach((markierung) => {
            markierung.addEventListener("change", loeschAuswahlAktualisieren);
        });
        loeschKnopf.addEventListener("click", async () => {
            const ausgewaehlt = markierungen.filter((markierung) => markierung.checked);
            if (!ausgewaehlt.length) return;
            if (!window.confirm(`${ausgewaehlt.length} markierte Datei(en) endgültig löschen?`)) return;

            loeschKnopf.disabled = true;
            const daten = new URLSearchParams();
            daten.set("bereich", dateilisteBereich);
            ausgewaehlt.forEach((markierung) => daten.append("name", markierung.value));

            try {
                const antwort = await fetch("/dateien-loeschen", { method: "POST", body: daten });
                const text = await antwort.text();
                if (!antwort.ok) throw new Error(text || "Löschen fehlgeschlagen");
                window.location.reload();
            } catch (fehler) {
                loeschStatus.textContent = "Löschen fehlgeschlagen: " + fehler.message;
                loeschStatus.classList.add("error");
                loeschKnopf.disabled = false;
            }
        });
        loeschAuswahlAktualisieren();
        '''
    stil = '''
        :root {
            color-scheme: light;
            --ink: #1d2a35;
            --muted: #66737d;
            --paper: #f6f3ed;
            --panel: #fffdf9;
            --line: #d9d5cc;
            --accent: #d45b36;
            --accent-dark: #9f351d;
            --teal: #236f70;
            --shadow: 0 18px 45px rgba(38, 48, 53, .12);
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            color: var(--ink);
            background:
                radial-gradient(circle at 12% 12%, rgba(212, 91, 54, .16), transparent 28%),
                radial-gradient(circle at 88% 78%, rgba(35, 111, 112, .15), transparent 30%),
                var(--paper);
            font-family: Georgia, "Times New Roman", serif;
        }

        main {
            width: min(760px, calc(100% - 32px));
            margin: 0 auto;
            padding: 9vh 0 48px;
        }

        .eyebrow {
            margin: 0 0 12px;
            color: var(--teal);
            font: 700 .78rem/1.2 Arial, sans-serif;
            letter-spacing: .14em;
            text-transform: uppercase;
        }

        h1 {
            max-width: 620px;
            margin: 0;
            font-size: clamp(2.7rem, 8vw, 5.7rem);
            line-height: .94;
            font-weight: 400;
            letter-spacing: 0;
        }

        .intro {
            max-width: 530px;
            margin: 24px 0 34px;
            color: var(--muted);
            font-size: 1.15rem;
            line-height: 1.55;
        }

        .upload-panel {
            padding: clamp(24px, 5vw, 42px);
            border: 1px solid rgba(217, 213, 204, .9);
            border-radius: 8px;
            background: rgba(255, 253, 249, .88);
            box-shadow: var(--shadow);
        }

        .wartung-upload { margin-bottom: 24px; }

        .wartung-upload h2 {
            margin: 0 0 18px;
            font-size: 1.3rem;
            font-weight: 400;
        }

        .wartung-upload input[type="file"] {
            display: block;
            width: 100%;
            margin-bottom: 16px;
            font: .95rem Arial, sans-serif;
        }

        .wartung-upload button {
            min-height: 44px;
            padding: 10px 18px;
            border: 0;
            border-radius: 4px;
            color: #fffdf9;
            background: var(--accent);
            font: 700 .95rem Arial, sans-serif;
            cursor: pointer;
        }

        .wartung-upload button:disabled { opacity: .5; cursor: not-allowed; }

        .loesch-aktion {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 8px 16px;
            margin: 14px 0;
        }

        .loesch-aktion button {
            min-height: 40px;
            padding: 9px 14px;
            border: 0;
            border-radius: 4px;
            color: #fffdf9;
            background: var(--accent-dark);
            font: 700 .9rem Arial, sans-serif;
            cursor: pointer;
        }

        .loesch-aktion button:disabled { opacity: .45; cursor: not-allowed; }

        #loesch-status {
            margin: 0;
            color: var(--accent-dark);
            font: .88rem/1.4 Arial, sans-serif;
        }

        #wartung-status {
            margin: 14px 0 0;
            color: var(--teal);
            font: .9rem/1.45 Arial, sans-serif;
        }

        #wartung-status.error { color: var(--accent-dark); }

        .zurueck {
            display: inline-block;
            margin: 0 0 20px;
            color: var(--teal);
            font: 700 .9rem/1.4 Arial, sans-serif;
            text-decoration-thickness: 1px;
            text-underline-offset: 3px;
        }

        .filter-label {
            display: block;
            margin-bottom: 8px;
            font: 700 .9rem/1.4 Arial, sans-serif;
        }

        #filter {
            width: 100%;
            min-height: 46px;
            padding: 10px 12px;
            border: 1px solid var(--line);
            border-radius: 4px;
            color: var(--ink);
            background: var(--panel);
            font: 1rem Arial, sans-serif;
        }

        #filter:focus-visible {
            outline: 2px solid var(--teal);
            outline-offset: 2px;
        }

        #treffer {
            min-height: 1.4em;
            margin: 14px 0;
            color: var(--muted);
            font: .88rem/1.4 Arial, sans-serif;
        }

        .dateiliste {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .dateiliste li {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 0;
            border-top: 1px solid var(--line);
        }

        .datei-markierung {
            flex: 0 0 auto;
            width: 18px;
            height: 18px;
            accent-color: var(--accent-dark);
        }

        .dateiliste a {
            color: var(--teal);
            font: .96rem/1.5 Arial, sans-serif;
            overflow-wrap: anywhere;
        }

        #leer {
            color: var(--muted);
            font: .96rem/1.5 Arial, sans-serif;
        }

        footer {
            margin-top: 30px;
            color: var(--muted);
            font: .76rem/1.5 Arial, sans-serif;
        }

        @media (max-width: 560px) {
            main { padding-top: 48px; }
        }
    '''

    return f'''<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="author" content="GitHub Copilot">
  <meta name="client" content="Andreas Sigismund">
  <title>{escape(titel)}</title>
    <style>{stil}</style>
</head>
<body>
  <main>
        <p class="eyebrow">AG-Server / Dateiablage</p>
    <h1>{escape(titel)}</h1>
        <p class="intro">Dateien im Verzeichnis {escape(ordner.name)}.</p>
        <a class="zurueck" href="/">Zur Startseite</a>
    {upload_bereich}
        <section class="upload-panel" aria-label="Dateiliste">
            <label class="filter-label" for="filter">Dateien filtern</label>
            <input id="filter" type="search" placeholder="Dateiname eingeben">
            <p id="treffer" aria-live="polite"></p>
        {loesch_bereich}
            <ul id="dateiliste" class="dateiliste" data-bereich="{escape(bereich, quote=True)}">
{inhalt}
            </ul>
            <p id="leer" hidden>Das Verzeichnis <code>{escape(ordner.name)}</code> ist derzeit leer.</p>
        </section>
        <footer>Webseite erstellt mit Unterstuetzung von GitHub Copilot. Fachliche Pruefung und Veroeffentlichung: Andreas Sigismund.</footer>
  </main>
    <script>
        const filter = document.querySelector("#filter");
        const dateien = [...document.querySelectorAll("#dateiliste li")];
        const treffer = document.querySelector("#treffer");
        const leer = document.querySelector("#leer");

        function dateienFiltern() {{
            const suchtext = filter.value.trim().toLocaleLowerCase("de");
            let sichtbar = 0;

            for (const eintrag of dateien) {{
                const passt = eintrag.textContent.toLocaleLowerCase("de").includes(suchtext);
                eintrag.hidden = !passt;
                if (passt) sichtbar++;
            }}

            leer.hidden = dateien.length > 0;
            treffer.textContent = dateien.length
                ? `${{sichtbar}} von ${{dateien.length}} Dateien`
                : "Keine Dateien vorhanden";
        }}

        filter.addEventListener("input", dateienFiltern);
        dateienFiltern();
{upload_script}
{loesch_script}
    </script>
</body>
</html>
'''


def minecraft_verzeichnis_html(
    ordner: Path,
    loeschen_erlaubt: bool,
    modus: str = "download",
) -> str:
        minecraft_wurzel = MINECRAFT_ORDNER.resolve()
        ordner = ordner.resolve()
        ordner.relative_to(minecraft_wurzel)
        pfad = ordner.relative_to(minecraft_wurzel).as_posix()
        if pfad == ".":
                pfad = ""

        eintraege = []
        for datei in sorted(ordner.iterdir(), key=lambda eintrag: (not eintrag.is_dir(), eintrag.name.casefold())):
                relativ = datei.relative_to(ordner).as_posix()
                ziel = datei.relative_to(minecraft_wurzel).as_posix()
                suffix = "/" if datei.is_dir() else ""
                link = quote(ziel, safe="/._-")
                loeschmarkierung = ""
                if loeschen_erlaubt and datei.is_file():
                        loeschmarkierung = (
                                f'<input class="datei-markierung" type="checkbox" '
                                f'value="{escape(relativ, quote=True)}" '
                                f'aria-label="{escape(relativ, quote=True)} zum Löschen markieren"> '
                        )
                eintraege.append(
                    f'<li>{loeschmarkierung}<a href="/minecraft/{escape(link, quote=True)}{suffix}?modus={escape(modus, quote=True)}">'
                        f'{escape(datei.name)}{suffix}</a></li>'
                )

        if not eintraege:
                eintraege.append('<li class="leer">Dieser Ordner ist leer.</li>')

        eltern_link = "/minecraft/"
        if pfad:
                eltern_pfad = Path(pfad).parent.as_posix()
                if eltern_pfad != ".":
                        eltern_link += quote(eltern_pfad, safe="/._-") + "/"
        eltern_link += f"?modus={quote(modus)}"
        aktueller_ordner_link = "/minecraft/"
        if pfad:
            aktueller_ordner_link += quote(pfad, safe="/._-") + "/"

        upload_bereich = ""
        upload_script = ""
        if modus == "upload":
                upload_bereich = '''
        <section class="panel upload-panel" aria-labelledby="upload-titel">
            <h2 id="upload-titel">Dateien in diesen Minecraft-Ordner hochladen</h2>
            <input id="datei-auswahl" type="file" multiple>
            <button id="hochladen" type="button" disabled>Hochladen</button>
            <p id="upload-status" role="status" aria-live="polite"></p>
        </section>'''
                upload_script = '''
        const auswahl = document.querySelector("#datei-auswahl");
        const hochladen = document.querySelector("#hochladen");
        const status = document.querySelector("#upload-status");
        const zielpfad = document.querySelector("#dateiliste").dataset.pfad;
        auswahl.addEventListener("change", () => { hochladen.disabled = auswahl.files.length === 0; });
        hochladen.addEventListener("click", async () => {
            const dateien = [...auswahl.files];
            hochladen.disabled = true;
            status.classList.remove("error");
            for (const [index, datei] of dateien.entries()) {
                status.textContent = `Lade ${index + 1} von ${dateien.length}: ${datei.name}`;
                const parameter = new URLSearchParams({ pfad: zielpfad, name: datei.name });
                try {
                    const antwort = await fetch("/minecraft-datei-upload?" + parameter, { method: "POST", body: datei });
                    const text = await antwort.text();
                    if (!antwort.ok) throw new Error(text || "Upload fehlgeschlagen");
                } catch (fehler) {
                    status.textContent = `Upload fehlgeschlagen: ${fehler.message}`;
                    status.classList.add("error");
                    hochladen.disabled = false;
                    return;
                }
            }
            window.location.reload();
        });
                '''

        loesch_bereich = ""
        loesch_script = ""
        if loeschen_erlaubt:
                loesch_bereich = '''
                <div class="loesch-aktion">
                        <button id="dateien-loeschen" type="button" disabled>Markierte Dateien löschen</button>
                        <p id="loesch-status" role="status" aria-live="polite"></p>
                </div>'''
                loesch_script = '''
                const markierungen = [...document.querySelectorAll(".datei-markierung")];
                const loeschKnopf = document.querySelector("#dateien-loeschen");
                const loeschStatus = document.querySelector("#loesch-status");
                const ordnerPfad = document.querySelector("#dateiliste").dataset.pfad;

                function loeschAuswahlAktualisieren() {
                        const anzahl = markierungen.filter((markierung) => markierung.checked).length;
                        loeschKnopf.disabled = anzahl === 0;
                        loeschKnopf.textContent = anzahl
                                ? `${anzahl} markierte Datei(en) löschen`
                                : "Markierte Dateien löschen";
                }

                markierungen.forEach((markierung) => markierung.addEventListener("change", loeschAuswahlAktualisieren));
                loeschKnopf.addEventListener("click", async () => {
                        const ausgewaehlt = markierungen.filter((markierung) => markierung.checked);
                        if (!ausgewaehlt.length || !window.confirm(`${ausgewaehlt.length} markierte Datei(en) endgültig löschen?`)) return;
                        loeschKnopf.disabled = true;
                        const daten = new URLSearchParams({ bereich: "minecraft", pfad: ordnerPfad });
                        ausgewaehlt.forEach((markierung) => daten.append("name", markierung.value));
                        try {
                                const antwort = await fetch("/dateien-loeschen", { method: "POST", body: daten });
                                const text = await antwort.text();
                                if (!antwort.ok) throw new Error(text || "Löschen fehlgeschlagen");
                                window.location.reload();
                        } catch (fehler) {
                                loeschStatus.textContent = "Löschen fehlgeschlagen: " + fehler.message;
                                loeschKnopf.disabled = false;
                        }
                });
                loeschAuswahlAktualisieren();
                '''

        return f'''<!doctype html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AG-Server | Minecraft</title>
    <style>
        :root {{ color-scheme: light; --ink: #1d2a35; --muted: #66737d; --paper: #f6f3ed; --panel: #fffdf9; --line: #d9d5cc; --accent: #d45b36; --teal: #236f70; }}
        * {{ box-sizing: border-box; }}
        body {{ margin: 0; min-height: 100vh; color: var(--ink); background: var(--paper); font-family: Georgia, "Times New Roman", serif; }}
        main {{ width: min(900px, calc(100% - 32px)); margin: 0 auto; padding: 44px 0; }}
        .eyebrow {{ margin: 0 0 10px; color: var(--teal); font: 700 .78rem Arial, sans-serif; text-transform: uppercase; }}
        h1 {{ margin: 0 0 14px; font-size: 2.5rem; font-weight: 400; }}
        .pfad {{ margin: 0 0 24px; color: var(--muted); font: .95rem Arial, sans-serif; overflow-wrap: anywhere; }}
        a {{ color: var(--teal); }}
        .modus {{ display: flex; flex-wrap: wrap; gap: 10px 18px; margin: 0 0 14px; font: 700 .9rem Arial, sans-serif; }}
        .panel {{ margin: 18px 0; padding: 20px; border: 1px solid var(--line); border-radius: 6px; background: var(--panel); }}
        .upload-panel h2 {{ margin: 0 0 14px; font-size: 1.25rem; font-weight: 400; }}
        input[type="file"] {{ display: block; width: 100%; margin: 12px 0; }}
        button {{ min-height: 40px; padding: 9px 14px; border: 0; border-radius: 4px; color: white; background: var(--accent); font: 700 .9rem Arial, sans-serif; cursor: pointer; }}
        button:disabled {{ opacity: .5; cursor: not-allowed; }}
        .loesch-aktion {{ display: flex; flex-wrap: wrap; align-items: center; gap: 8px 14px; margin: 10px 0; }}
        .loesch-aktion button {{ background: #9f351d; }}
        #upload-status, #loesch-status {{ min-height: 1.4em; margin: 10px 0 0; color: var(--muted); font: .9rem/1.4 Arial, sans-serif; }}
        #upload-status.error, #loesch-status.error {{ color: #9f351d; }}
        ul {{ margin: 0; padding: 0; list-style: none; }}
        li {{ display: flex; align-items: center; gap: 10px; padding: 11px 0; border-top: 1px solid var(--line); font: .95rem/1.4 Arial, sans-serif; }}
        li a {{ overflow-wrap: anywhere; }}
        .datei-markierung {{ width: 18px; height: 18px; accent-color: #9f351d; }}
        .zurueck {{ display: inline-block; margin-bottom: 20px; font: 700 .9rem Arial, sans-serif; }}
        @media (max-width: 560px) {{ main {{ padding-top: 28px; }} .panel {{ padding: 15px; }} }}
    </style>
</head>
<body>
    <main>
        <p class="eyebrow">AG-Server / Minecraft</p>
        <h1>Minecraft-Dateien</h1>
        <p class="pfad">Unterordner: <code>/minecraft/{escape(pfad)}</code></p>
        <nav class="modus">
            <a href="{escape(aktueller_ordner_link + '?modus=download', quote=True)}">Minecraft - Download</a>
            <a href="{escape(aktueller_ordner_link + '?modus=upload', quote=True)}">Minecraft - Upload</a>
        </nav>
        <a class="zurueck" href="{escape(eltern_link, quote=True)}">↑ Übergeordneter Ordner</a>
        {upload_bereich}
        <section class="panel" aria-label="Minecraft-Dateien">
            {loesch_bereich}
            <ul id="dateiliste" data-pfad="{escape(pfad, quote=True)}">
{chr(10).join(eintraege)}
            </ul>
        </section>
    </main>
    <script>
{upload_script}
{loesch_script}
    </script>
</body>
</html>'''


def build_version_text() -> str:
    datei = Path(__file__)
    try:
        zeitzone = ZoneInfo("Europe/Berlin")
        zeitzonen_text = " (Berlin)"
    except Exception:
        zeitzone = datetime.now().astimezone().tzinfo
        zeitzonen_text = ""

    zeitpunkt = datetime.fromtimestamp(datei.stat().st_mtime, tz=zeitzone)
    return f"Version 1.1 | Letzte Änderung: {zeitpunkt.strftime('%Y-%m-%d %H:%M:%S')}{zeitzonen_text}"


def lokale_ip():
    """Ermittelt die IPv4-Adresse des PCs im lokalen Netzwerk."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Es werden keine Daten gesendet. Die Verbindung dient nur dazu,
        # die für das lokale Netz verwendete IP-Adresse zu bestimmen.
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        sock.close()


def beende_vorherigen_ag_server() -> None:
    if os.name != "nt":
        return

    skriptpfad = str(Path(__file__).resolve()).replace("'", "''")
    powershell = (
        "$ziel = '" + skriptpfad + "'; "
        "$pids = @(Get-NetTCPConnection -LocalPort " + str(PORT) + " -State Listen "
        "-ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique); "
        "foreach ($prozessId in $pids) { "
        "$prozess = Get-CimInstance Win32_Process -Filter \"ProcessId = $prozessId\"; "
        "if ($prozess.CommandLine -like ('*' + $ziel + '*')) { Stop-Process -Id $prozessId -Force } "
        "}"
    )
    subprocess.run(
        ["powershell.exe", "-NoProfile", "-Command", powershell],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def oeffne_in_chrome(url: str) -> None:
    if os.name != "nt":
        webbrowser.open(url)
        return

    chrome_pfade = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    for chrome in chrome_pfade:
        if chrome.is_file():
            subprocess.Popen(
                [str(chrome), url],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return

    webbrowser.open(url)


def serverhinweis_html() -> str:
        ip = escape(lokale_ip())
        pc_name = escape(socket.gethostname())
        version = escape(build_version_text())
        return f'''<header role="status" style="
            width: 100%;
            padding: 16px 20px;
            color: #fffdf9;
            background: #236f70;
            font: 700 18px/1.5 Arial, sans-serif;
        ">
            <div style="
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                justify-content: space-between;
                gap: 12px 24px;
                width: min(760px, calc(100% - 32px));
                margin: 0 auto;
            ">
                <div style="display: flex; flex: 1 1 420px; flex-wrap: wrap; align-items: center; justify-content: flex-start; gap: 8px">
                    <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 12px 16px">
                        <img src="/bilder/mrge-logo.gif" alt="MRGE-Schullogo" style="display: block; width: auto; height: 48px; max-width: 150px; object-fit: contain; padding: 4px 8px; border-radius: 4px; background: #fffdf9">
                        <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 6px 10px">
                            <span style="font-size: 32px">{pc_name}</span>
                            <span style="font-size: 32px">{ip}</span>
                        </div>
                    </div>
                    <span>{version}</span>
                </div>
            </div>
        </header>'''


class AGServer(SimpleHTTPRequestHandler):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASIS_ORDNER), **kwargs)

    def transfer_protokoll_starten(self, aktion: str, dateiname: str) -> None:
        self._transfer_aktion = aktion
        self._transfer_dateiname = dateiname
        self._transfer_bytes = 0
        self._transfer_protokolliert = False

    def send_response(self, code, message=None):
        if (getattr(self, "_transfer_aktion", None)
                and not getattr(self, "_transfer_protokolliert", False)):
            TRANSFER_LOG.info(
                "%s Serverrechner=%s ClientIP=%s Datei=%r Bytes=%s HTTP=%s",
                self._transfer_aktion,
                socket.gethostname(),
                self.client_address[0],
                self._transfer_dateiname,
                self._transfer_bytes,
                code,
            )
            self._transfer_protokolliert = True
        super().send_response(code, message)

    def sende_html(self, html: str) -> None:
        body_position = html.lower().find("<body")
        if body_position >= 0:
            body_start = html.find(">", body_position)
            if body_start >= 0:
                html = (
                    html[:body_start + 1]
                    + "\n"
                    + serverhinweis_html()
                    + html[body_start + 1:]
                )

        inhalt = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(inhalt)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(inhalt)

    def do_GET(self):
        anfrage_pfad = urlparse(self.path).path
        pfad = anfrage_pfad.rstrip("/")

        if anfrage_pfad.startswith("/minecraft/") and anfrage_pfad.endswith("/"):
            dateipfad = Path(self.translate_path(self.path)).resolve()
            try:
                dateipfad.relative_to(MINECRAFT_ORDNER.resolve())
            except ValueError:
                self.send_error(404, "Minecraft-Ordner nicht gefunden")
                return
            if not dateipfad.is_dir():
                self.send_error(404, "Minecraft-Ordner nicht gefunden")
                return
            modus = parse_qs(urlparse(self.path).query).get("modus", ["download"])[0]
            if modus not in {"download", "upload"}:
                self.send_error(400, "Unbekannter Minecraft-Modus")
                return
            self.sende_html(minecraft_verzeichnis_html(dateipfad, self.ist_client_local(), modus))
            return

        alte_pfade = {
            "/uploads": "/upload/",
            "/uploads.html": "/upload/",
            "/downloads": "/download/",
            "/downloads.html": "/download/",
        }
        if pfad in alte_pfade:
            self.send_response(301)
            self.send_header("Location", alte_pfade[pfad])
            self.end_headers()
            return

        if pfad in {"/protokoll", "/protokoll.html"}:
            if not self.ist_client_local():
                self.send_error(403, "Protokoll nur auf dem Server-PC verfügbar")
                return
            self.sende_html(transferprotokoll_html())
            return

        verzeichnisse = {
            "/download": (DOWNLOAD_ORDNER, "Datei download"),
            "/download.html": (DOWNLOAD_ORDNER, "Datei download"),
            "/upload": (UPLOAD_ORDNER, "Datei upload"),
            "/upload.html": (UPLOAD_ORDNER, "Datei upload"),
            "/wartung": (BASIS_ORDNER / "wartung", "Wartungsverzeichnis"),
            "/wartungsverzeichnis.html": (BASIS_ORDNER / "wartung", "Wartungsverzeichnis"),
        }
        verzeichnis = verzeichnisse.get(pfad)

        if verzeichnis is not None:
            verwaltbare_ordner = {
                DOWNLOAD_ORDNER,
                UPLOAD_ORDNER,
                BASIS_ORDNER / "wartung",
            }
            upload_erlaubt = verzeichnis[0] in verwaltbare_ordner and self.ist_client_local()
            self.sende_html(verzeichnis_html(*verzeichnis, upload_erlaubt=upload_erlaubt))
            return

        if anfrage_pfad.lower().endswith(".html") or anfrage_pfad.endswith("/"):
            dateipfad = Path(self.translate_path(self.path))
            if dateipfad.is_dir():
                dateipfad /= "index.html"

            if dateipfad.is_file():
                try:
                    html = dateipfad.read_text(encoding="utf-8")
                except (OSError, UnicodeError):
                    self.send_error(500, "HTML-Datei konnte nicht gelesen werden")
                    return

                if anfrage_pfad in {"/", "/index.html"} and self.ist_client_local():
                    pfad_hinweis = (
                        '<p class="status" style="overflow-wrap: anywhere">'
                        "Lokales Server-Verzeichnis: "
                        f"<code>{escape(str(BASIS_ORDNER))}</code></p>"
                    )
                    marker = '<p class="intro">'
                    protokoll_link = (
                        '<p class="status"><a href="/protokoll">'
                        "Transferprotokoll anzeigen</a></p>"
                    )
                    html = html.replace(
                        marker,
                        pfad_hinweis + "\n    " + protokoll_link + "\n    " + marker,
                        1,
                    )

                self.sende_html(html)
                return

        dateipfad = Path(self.translate_path(self.path))
        if not anfrage_pfad.endswith("/") and (dateipfad.is_file() or dateipfad.suffix):
            try:
                groesse = dateipfad.stat().st_size
            except OSError:
                groesse = 0
            self.transfer_protokoll_starten("DOWNLOAD", anfrage_pfad)
            self._transfer_bytes = groesse

        super().do_GET()

    def do_POST(self):
        url = urlparse(self.path)

        if url.path == "/minecraft-datei-upload":
            parameter = parse_qs(url.query)
            pfad = parameter.get("pfad", [""])[0]
            name = parameter.get("name", [""])[0]
            rel = Path(pfad) / Path(name).name
            self.transfer_protokoll_starten("UPLOAD", f"minecraft/{rel.as_posix()}")
            self.do_minecraft_datei_upload(url.query)
            return

        if url.path == "/minecraft-root-upload":
            name = parse_qs(url.query).get("name", [""])[0]
            self.transfer_protokoll_starten("UPLOAD", f"minecraft/{Path(name).name}")
            self.do_minecraft_root_upload(url.query)
            return

        if url.path == "/minecraft-upload":
            parameter = parse_qs(url.query)
            bereich = parameter.get("bereich", ["saves"])[0]
            name = parameter.get("name", [""])[0]
            self.transfer_protokoll_starten(
                "UPLOAD",
                f"minecraft/instanzen/26.2/{bereich}/{Path(name).name}",
            )
            self.do_minecraft_upload(url.query)
            return

        if url.path == "/wartung-upload":
            name = parse_qs(url.query).get("name", [""])[0]
            self.transfer_protokoll_starten("UPLOAD", f"wartung/{Path(name).name}")
            self.do_wartung_upload(url.query)
            return

        if url.path in {"/download-upload", "/downloads-upload"}:
            name = parse_qs(url.query).get("name", [""])[0]
            self.transfer_protokoll_starten("UPLOAD", f"download/{Path(name).name}")
            self.do_download_upload(url.query)
            return

        if url.path == "/dateien-loeschen":
            self.do_dateien_loeschen()
            return

        if url.path == "/wartung-loeschen":
            self.do_wartung_loeschen()
            return

        if url.path != "/upload":
            self.send_error(404, "Unbekannte Upload-Adresse")
            return

        parameter = parse_qs(url.query)
        name = parameter.get("name", [""])[0]
        self.transfer_protokoll_starten("UPLOAD", f"upload/{Path(name).name}")

        if "name" not in parameter:
            self.send_error(400, "Dateiname fehlt")
            return

        # Nur den eigentlichen Dateinamen übernehmen
        dateiname = Path(parameter["name"][0]).name
        if not dateiname or dateiname in {".", ".."}:
            self.send_error(400, "Ungültiger Dateiname")
            return

        try:
            groesse = int(self.headers.get("Content-Length", 0))
        except ValueError:
            self.send_error(400, "Ungültige Dateigröße")
            return

        if groesse <= 0:
            self.send_error(400, "Keine Datei empfangen")
            return

        if groesse > MAX_GROESSE:
            self.send_error(413, "Datei zu groß")
            return

        ziel = UPLOAD_ORDNER / dateiname

        try:
            with ziel.open("wb") as datei:
                verbleibend = groesse

                while verbleibend > 0:
                    block = self.rfile.read(min(65536, verbleibend))

                    if not block:
                        break

                    datei.write(block)
                    verbleibend -= len(block)

        except OSError as fehler:
            self.send_error(500, str(fehler))
            return

        self._transfer_bytes = groesse - verbleibend
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()

        self.wfile.write(
            f"OK: {dateiname} wurde gespeichert.".encode("utf-8")
        )

    def do_download_upload(self, query: str) -> None:
        if not self.ist_client_local():
            self.send_error(403, "Hinzufügen zum Downloadverzeichnis nur auf dem Server-PC erlaubt")
            return

        parameter = parse_qs(query)
        if "name" not in parameter:
            self.send_error(400, "Dateiname fehlt")
            return

        dateiname = Path(parameter["name"][0]).name
        if not dateiname or dateiname in {".", ".."}:
            self.send_error(400, "Ungültiger Dateiname")
            return

        try:
            groesse = int(self.headers.get("Content-Length", 0))
        except ValueError:
            self.send_error(400, "Ungültige Dateigröße")
            return

        if groesse <= 0:
            self.send_error(400, "Keine Datei empfangen")
            return
        if groesse > MAX_GROESSE:
            self.send_error(413, "Datei zu groß (maximal 200 MB)")
            return

        ziel = DOWNLOAD_ORDNER / dateiname
        vollstaendig = True
        angelegt = False
        try:
            with ziel.open("xb") as datei:
                angelegt = True
                verbleibend = groesse
                while verbleibend > 0:
                    block = self.rfile.read(min(65536, verbleibend))
                    if not block:
                        vollstaendig = False
                        break
                    datei.write(block)
                    verbleibend -= len(block)
        except FileExistsError:
            self.send_error(409, "Eine Datei mit diesem Namen ist bereits vorhanden")
            return
        except OSError as fehler:
            if angelegt:
                ziel.unlink(missing_ok=True)
            self.send_error(500, str(fehler))
            return

        if not vollstaendig:
            ziel.unlink(missing_ok=True)
            self.send_error(400, "Upload unvollständig")
            return

        antwort = f"{dateiname} wurde im Downloadverzeichnis gespeichert.".encode("utf-8")
        self._transfer_bytes = groesse
        self.send_response(201)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(antwort)))
        self.end_headers()
        self.wfile.write(antwort)

    def do_minecraft_root_upload(self, query: str) -> None:
        parameter = parse_qs(query)
        if "name" not in parameter:
            self.send_error(400, "Dateiname fehlt")
            return

        dateiname = Path(parameter["name"][0]).name
        if not dateiname or dateiname in {".", ".."}:
            self.send_error(400, "Ungültiger Dateiname")
            return

        try:
            groesse = int(self.headers.get("Content-Length", 0))
        except ValueError:
            self.send_error(400, "Ungültige Dateigröße")
            return

        if groesse <= 0:
            self.send_error(400, "Keine Datei empfangen")
            return
        if groesse > MAX_GROESSE:
            self.send_error(413, "Datei zu groß (maximal 200 MB)")
            return

        ziel = MINECRAFT_ORDNER / dateiname
        vollstaendig = True
        angelegt = False
        try:
            with ziel.open("xb") as datei:
                angelegt = True
                verbleibend = groesse
                while verbleibend > 0:
                    block = self.rfile.read(min(65536, verbleibend))
                    if not block:
                        vollstaendig = False
                        break
                    datei.write(block)
                    verbleibend -= len(block)
        except FileExistsError:
            self.send_error(409, "Eine Datei mit diesem Namen ist bereits vorhanden")
            return
        except OSError as fehler:
            if angelegt:
                ziel.unlink(missing_ok=True)
            self.send_error(500, str(fehler))
            return

        if not vollstaendig:
            ziel.unlink(missing_ok=True)
            self.send_error(400, "Upload unvollständig")
            return

        antwort = f"{dateiname} wurde im Minecraft-Ordner gespeichert.".encode("utf-8")
        self._transfer_bytes = groesse
        self.send_response(201)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(antwort)))
        self.end_headers()
        self.wfile.write(antwort)

    def do_minecraft_datei_upload(self, query: str) -> None:
        parameter = parse_qs(query)
        if "name" not in parameter:
            self.send_error(400, "Dateiname fehlt")
            return

        dateiname = Path(parameter["name"][0]).name
        if not dateiname or dateiname in {".", ".."}:
            self.send_error(400, "Ungültiger Dateiname")
            return

        minecraft_wurzel = MINECRAFT_ORDNER.resolve()
        ordner = (minecraft_wurzel / parameter.get("pfad", [""])[0]).resolve()
        try:
            ordner.relative_to(minecraft_wurzel)
        except ValueError:
            self.send_error(400, "Ungültiger Minecraft-Unterordner")
            return
        if not ordner.is_dir():
            self.send_error(404, "Minecraft-Unterordner nicht gefunden")
            return

        try:
            groesse = int(self.headers.get("Content-Length", 0))
        except ValueError:
            self.send_error(400, "Ungültige Dateigröße")
            return

        if groesse <= 0:
            self.send_error(400, "Keine Datei empfangen")
            return
        if groesse > MAX_GROESSE:
            self.send_error(413, "Datei zu groß (maximal 200 MB)")
            return

        ziel = ordner / dateiname
        vollstaendig = True
        angelegt = False
        try:
            with ziel.open("xb") as datei:
                angelegt = True
                verbleibend = groesse
                while verbleibend > 0:
                    block = self.rfile.read(min(65536, verbleibend))
                    if not block:
                        vollstaendig = False
                        break
                    datei.write(block)
                    verbleibend -= len(block)
        except FileExistsError:
            self.send_error(409, "Eine Datei mit diesem Namen ist bereits vorhanden")
            return
        except OSError as fehler:
            if angelegt:
                ziel.unlink(missing_ok=True)
            self.send_error(500, str(fehler))
            return

        if not vollstaendig:
            ziel.unlink(missing_ok=True)
            self.send_error(400, "Upload unvollständig")
            return

        antwort = f"{dateiname} wurde in minecraft/{ordner.relative_to(minecraft_wurzel).as_posix()} gespeichert.".encode("utf-8")
        self._transfer_bytes = groesse
        self.send_response(201)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(antwort)))
        self.end_headers()
        self.wfile.write(antwort)

    def do_minecraft_upload(self, query: str) -> None:
        parameter = parse_qs(query)
        if "name" not in parameter:
            self.send_error(400, "Dateiname fehlt")
            return

        bereich = parameter.get("bereich", ["saves"])[0]
        upload_ordner = {
            "mods": MINECRAFT_26_2_ORDNER / "mods",
            "resourcepacks": MINECRAFT_26_2_ORDNER / "resourcepacks",
            "saves": MINECRAFT_26_2_SAVES_ORDNER,
            "schematics": MINECRAFT_26_2_ORDNER / "schematics",
        }.get(bereich)
        erlaubte_endungen = {
            "mods": {".jar"},
            "resourcepacks": {".zip"},
            "saves": {".zip"},
            "schematics": {".schem", ".schematic", ".nbt"},
        }
        if upload_ordner is None:
            self.send_error(400, "Unbekannter Minecraft-Bereich")
            return

        dateiname = Path(parameter["name"][0]).name
        if (not dateiname or dateiname in {".", ".."}
                or Path(dateiname).suffix.lower() not in erlaubte_endungen[bereich]):
            endungen = ", ".join(sorted(erlaubte_endungen[bereich]))
            self.send_error(400, f"Für {bereich} sind nur diese Dateitypen erlaubt: {endungen}")
            return

        try:
            groesse = int(self.headers.get("Content-Length", 0))
        except ValueError:
            self.send_error(400, "Ungültige Dateigröße")
            return

        if groesse <= 0:
            self.send_error(400, "Keine Datei empfangen")
            return
        if groesse > MAX_GROESSE:
            self.send_error(413, "Datei zu groß")
            return

        ziel = upload_ordner / dateiname
        vollstaendig = True
        angelegt = False
        try:
            with ziel.open("xb") as datei:
                angelegt = True
                verbleibend = groesse
                while verbleibend > 0:
                    block = self.rfile.read(min(65536, verbleibend))
                    if not block:
                        vollstaendig = False
                        break
                    datei.write(block)
                    verbleibend -= len(block)
        except FileExistsError:
            self.send_error(409, "Ein Backup mit diesem Namen ist bereits vorhanden")
            return
        except OSError as fehler:
            if angelegt:
                ziel.unlink(missing_ok=True)
            self.send_error(500, str(fehler))
            return

        if not vollstaendig:
            ziel.unlink(missing_ok=True)
            self.send_error(400, "Upload unvollständig")
            return

        antwort = f"{dateiname} wurde in minecraft/instanzen/26.2/{bereich} gespeichert.".encode("utf-8")
        self._transfer_bytes = groesse
        self.send_response(201)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(antwort)))
        self.end_headers()
        self.wfile.write(antwort)

    def ist_client_local(self) -> bool:
        client_ip = self.client_address[0]
        return client_ip.startswith("127.") or client_ip == lokale_ip()

    def do_wartung_upload(self, query: str) -> None:
        if not self.ist_client_local():
            self.send_error(403, "Upload nur auf dem Server-PC erlaubt")
            return

        parameter = parse_qs(query)
        if "name" not in parameter:
            self.send_error(400, "Dateiname fehlt")
            return

        dateiname = Path(parameter["name"][0]).name
        if not dateiname or dateiname in {".", ".."}:
            self.send_error(400, "Ungültiger Dateiname")
            return

        try:
            groesse = int(self.headers.get("Content-Length", 0))
        except ValueError:
            self.send_error(400, "Ungültige Dateigröße")
            return

        if groesse <= 0:
            self.send_error(400, "Keine Datei empfangen")
            return
        if groesse > MAX_GROESSE:
            self.send_error(413, "Datei zu groß (maximal 200 MB)")
            return

        ziel = BASIS_ORDNER / "wartung" / dateiname
        if ziel.exists():
            self.send_error(409, "Eine Datei mit diesem Namen ist bereits vorhanden")
            return

        vollstaendig = True
        try:
            with ziel.open("xb") as datei:
                verbleibend = groesse
                while verbleibend > 0:
                    block = self.rfile.read(min(65536, verbleibend))
                    if not block:
                        vollstaendig = False
                        break
                    datei.write(block)
                    verbleibend -= len(block)
        except OSError as fehler:
            self.send_error(500, str(fehler))
            return

        if not vollstaendig:
            ziel.unlink(missing_ok=True)
            self.send_error(400, "Upload unvollständig")
            return

        self._transfer_bytes = groesse
        self.send_response(201)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(f"{dateiname} wurde gespeichert.".encode("utf-8"))

    def do_wartung_loeschen(self) -> None:
        self.do_dateien_loeschen("wartung")

    def do_dateien_loeschen(self, bereich_erzwungen: str | None = None) -> None:
        if not self.ist_client_local():
            self.send_error(403, "Löschen nur auf dem Server-PC erlaubt")
            return

        try:
            groesse = int(self.headers.get("Content-Length", 0))
        except ValueError:
            self.send_error(400, "Ungültige Anfragegröße")
            return

        if groesse <= 0 or groesse > 1024 * 1024:
            self.send_error(400, "Ungültige oder zu große Auswahl")
            return

        try:
            daten = self.rfile.read(groesse).decode("utf-8")
        except UnicodeDecodeError:
            self.send_error(400, "Ungültige Anfragekodierung")
            return

        parameter = parse_qs(daten)
        bereich = bereich_erzwungen or parameter.get("bereich", [""])[0]
        ordner_pfade = {
            "wartung": BASIS_ORDNER / "wartung",
            "uploads": UPLOAD_ORDNER,
            "upload": UPLOAD_ORDNER,
            "download": DOWNLOAD_ORDNER,
            "downloads": DOWNLOAD_ORDNER,
            "minecraft": MINECRAFT_ORDNER,
        }
        ordner = ordner_pfade.get(bereich)
        if ordner is None:
            self.send_error(400, "Unbekanntes Dateiverzeichnis")
            return

        namen = list(dict.fromkeys(parameter.get("name", [])))
        if not namen or len(namen) > 1000:
            self.send_error(400, "Keine gültigen Dateien ausgewählt")
            return

        ordner = ordner.resolve()
        unterordner = parameter.get("pfad", [""])[0]
        if bereich == "minecraft" and unterordner:
            ordner = (ordner / unterordner).resolve()
            try:
                ordner.relative_to(MINECRAFT_ORDNER.resolve())
            except ValueError:
                self.send_error(400, "Ungültiger Minecraft-Pfad")
                return
            if not ordner.is_dir():
                self.send_error(404, "Minecraft-Unterordner nicht gefunden")
                return
        ziele = []
        for name in namen:
            ziel = (ordner / name).resolve()
            try:
                ziel.relative_to(ordner)
            except ValueError:
                self.send_error(400, "Ungültiger Dateipfad")
                return
            if ziel == ordner or not ziel.is_file():
                self.send_error(404, "Datei nicht gefunden")
                return
            ziele.append(ziel)

        try:
            transfer_bytes = sum(ziel.stat().st_size for ziel in ziele)
            self.transfer_protokoll_starten("DELETE", f"{bereich}/{len(ziele)} Datei(en)")
            self._transfer_bytes = transfer_bytes
            for ziel in ziele:
                ziel.unlink()
        except OSError as fehler:
            self.send_error(500, str(fehler))
            return

        antwort = f"{len(ziele)} Datei(en) wurden gelöscht.".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(antwort)))
        self.end_headers()
        self.wfile.write(antwort)


if __name__ == "__main__":
    beende_vorherigen_ag_server()
    server = ThreadingHTTPServer(
        ("0.0.0.0", PORT),
        AGServer
    )

    ip = lokale_ip()
    url = f"http://{ip}:{PORT}/"

    print()
    print("AG-Server gestartet")
    print("-------------------")
    print(build_version_text())
    print(f"IP-Adresse des PCs : {ip}")
    print(f"Aufruf im Browser  : {url}")
    print(f"Upload-Ordner      : {UPLOAD_ORDNER.resolve()}")
    print(f"Download-Ordner    : {DOWNLOAD_ORDNER.resolve()}")
    print(f"Transferprotokoll  : {LOG_DATEI.resolve()}")
    print("Beenden mit Strg+C")
    print()

    oeffne_in_chrome(url)
    server.serve_forever()