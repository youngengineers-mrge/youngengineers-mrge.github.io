@echo off
echo.
echo Starte Wartungstool V1.0
echo.


setlocal

set "ZIEL=C:\Users\Public\Programme\"
set "MARKER=%ZIEL%ag-tool-v1.0-erfolgreich.txt"
if exist "%MARKER%" (
    echo Wartungstool wurde bereits erfolgreich ausgefuehrt.
    echo Markierungsdatei: "%MARKER%"
    exit /b 0
)

set "ZIPNAME=thonny-5.0.0-windows-portable-x64.zip"

set "SEVENZIP=C:\Program Files\7-Zip\7z.exe"
set "SEVENZIP_DIR=C:\Users\Public\programme\7-zip"
if exist "%SEVENZIP%" goto sevenzip_ready

set "SEVENZIP=%SEVENZIP_DIR%\7za.exe"
if exist "%SEVENZIP%" goto sevenzip_ready

set "SEVENZIP_BOOTSTRAP=%SEVENZIP_DIR%\7zr.exe"
set "SEVENZIP_ARCHIVE=%SEVENZIP_DIR%\7z2603-extra.7z"
if not exist "%SEVENZIP_DIR%" mkdir "%SEVENZIP_DIR%"
if errorlevel 1 goto sevenzip_setup_failed

echo Lade 7-Zip-Entpacker herunter ...
curl.exe -f -L -o "%SEVENZIP_BOOTSTRAP%" "https://github.com/ip7z/7zip/releases/download/26.03/7zr.exe"
if errorlevel 1 goto sevenzip_setup_failed

curl.exe -f -L -o "%SEVENZIP_ARCHIVE%" "https://github.com/ip7z/7zip/releases/download/26.03/7z2603-extra.7z"
if errorlevel 1 goto sevenzip_setup_failed

echo Entpacke 7-Zip-Werkzeuge ...
"%SEVENZIP_BOOTSTRAP%" x "%SEVENZIP_ARCHIVE%" -o"%SEVENZIP_DIR%" -y
if errorlevel 1 goto sevenzip_setup_failed
if not exist "%SEVENZIP%" goto sevenzip_setup_failed
goto sevenzip_ready

:sevenzip_setup_failed
echo FEHLER: 7-Zip konnte nicht bereitgestellt werden.
exit /b 1

:sevenzip_ready
set "DOWNLOAD=C:\Users\Public\programme\wartung\download"
set "URL=http://192.168.2.107:8000/wartung/download"


if not exist "%DOWNLOAD%" mkdir "%DOWNLOAD%"
if errorlevel 1 (
    echo FEHLER: Downloadordner konnte nicht erstellt werden.
    exit /b 1
)

echo.
echo =========== thonny-5.0.0-windows-portable-x64 ============ 
echo.

echo Laden von "%ZIPNAME%" ...
curl.exe -f -L -o "%DOWNLOAD%\%ZIPNAME%" "%URL%/%ZIPNAME%"
if errorlevel 1 (
    echo FEHLER: Download fehlgeschlagen.
    exit /b 1
)

echo Download abgeschlossen: "%DOWNLOAD%\%ZIPNAME%"

echo Entpacke "%ZIPNAME%" ...

"%SEVENZIP%" x "%DOWNLOAD%\%ZIPNAME%" -o"%ZIEL%\thonny-5.0.0-windows-portable-x64" -y -bsp1 -bb0
if errorlevel 1 (
    echo FEHLER: Entpacken von "%ZIPNAME%" fehlgeschlagen.
    exit /b 1
)

echo.
echo =========== ChromiumPortable ===========
echo.

set "ZIPNAME=ChromiumPortable.zip"

echo Laden von "%ZIPNAME%" ...
curl.exe -f -L -o "%DOWNLOAD%\%ZIPNAME%" "%URL%/%ZIPNAME%"
if errorlevel 1 (
    echo FEHLER: Download fehlgeschlagen.
    exit /b 1
)

echo Download abgeschlossen: "%DOWNLOAD%\%ZIPNAME%"

echo Entpacke "%ZIPNAME%" ...
"%SEVENZIP%" x "%DOWNLOAD%\%ZIPNAME%" -o"%ZIEL%" -y -bsp1 -bb0
if errorlevel 1 (
    echo FEHLER: Entpacken von "%ZIPNAME%" fehlgeschlagen.
    exit /b 1
)

echo.
echo =========== WinPython64-3.14.7.0dot ===========
echo.

set "ZIPNAME=WinPython64-3.14.7.0dot.zip"
echo Laden von "%ZIPNAME%" ...
curl.exe -f -L -o "%DOWNLOAD%\%ZIPNAME%" "%URL%/%ZIPNAME%"
if errorlevel 1 (
    echo FEHLER: Download fehlgeschlagen.
    exit /b 1
)
echo Download abgeschlossen: "%DOWNLOAD%\%ZIPNAME%"
echo Entpacke "%ZIPNAME%" ...
"%SEVENZIP%" x "%DOWNLOAD%\%ZIPNAME%" -o"%ZIEL%" -y -bsp1 -bb0
if errorlevel 1 (
    echo FEHLER: Entpacken von "%ZIPNAME%" fehlgeschlagen.
    exit /b 1
)

echo.
echo =========== PrusaSlicer ===========
echo.

set "ZIPNAME=Prusa3D.zip"
echo Laden von "%ZIPNAME%" ...
curl.exe -f -L -o "%DOWNLOAD%\%ZIPNAME%" "%URL%/%ZIPNAME%"
if errorlevel 1 (
    echo FEHLER: Download fehlgeschlagen.
    exit /b 1
)
echo Download abgeschlossen: "%DOWNLOAD%\%ZIPNAME%"
echo Entpacke "%ZIPNAME%" ...
"%SEVENZIP%" x "%DOWNLOAD%\%ZIPNAME%" -o"%ZIEL%" -y -bsp1 -bb0
if errorlevel 1 (
    echo FEHLER: Entpacken von "%ZIPNAME%" fehlgeschlagen.
    exit /b 1
)

echo.
echo Erstelle Ausfuehrungssperre ...
> "%MARKER%" echo Wartungstool V1.0 erfolgreich abgeschlossen.
if errorlevel 1 (
    echo FEHLER: Markierungsdatei konnte nicht erstellt werden.
    exit /b 1
)
echo Markierungsdatei erstellt: "%MARKER%"

endlocal

