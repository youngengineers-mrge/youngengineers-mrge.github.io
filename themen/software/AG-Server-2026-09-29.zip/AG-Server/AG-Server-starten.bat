@echo off
setlocal
cd /d "%~dp0"
python ag_server.py
if errorlevel 1 pause
endlocal
